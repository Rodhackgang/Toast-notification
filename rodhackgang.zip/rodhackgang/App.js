import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, Button, Alert, ToastAndroid } from 'react-native';

const App = () => {
  const [name, setName] = useState('');
 const [submitted, setsubmitted]= useState(false)

 const onpress= ()=>{
      if(name.length >3){
           setsubmitted(!submitted);
      }else{
          Alert.alert('Erreur', 'Le nom ne peut pas etre inferieur à 3 caractères',
          [
            {
              text: 'Compris', 
              onPress:()=>{console.warn('Compris es cliquer')}
            },
            {
              text: 'Je m\'en fou', 
              onPress:()=>{console.warn('Compris es cliquer')}
            },
            {
              text: 'OK', onPress:()=>{console.warn('Compris es cliquer')}
            },
          ], {cancelable: true}) 
          ToastAndroid.showWithGravity('Un message qui va te notifer enbas de ton ecran',
                ToastAndroid.LONG,
                ToastAndroid.CENTER,
          )
      }   
 }
  const handleNameChange = (text) => {
    setName(text);
  };

  return (
    <View style={styles.container}>
      <View style={styles.paragraph}>
        {
          submitted? 
          <Text style={styles.nom}>Vous ets connecter en tant que {name}</Text>:
          null
        }

        
        <TextInput
          placeholder='Veuillez entrer votre nom'
          style={styles.input}
          onChangeText={(value)=>setName(value)}
        />
        <Button 
            title={ submitted? 'Effacer': 'Valider'}
            style={styles.button}
            onPress={onpress}
            android_ripple={{color:'red'}}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#aeffcd',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paragraph: {
    backgroundColor: 'orange',
    padding: 20,
    width: '90%',
    borderRadius: 10,
  },
  nom: {
    backgroundColor: 'red',
    padding: 10,
    marginBottom: 10,
    textAlign: 'center',
  },
  input: {
    marginTop: 20,
    textAlign: 'center',
    borderWidth: 1,
    padding: 10,
    borderRadius: 10,
    marginBottom: 20,
  },
  button:{
    marginTop: 10,
  }
});

export default App;
